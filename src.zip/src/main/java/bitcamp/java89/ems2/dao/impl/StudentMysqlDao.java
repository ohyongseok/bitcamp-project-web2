package bitcamp.java89.ems2.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bitcamp.java89.ems2.dao.StudentDao;
import bitcamp.java89.ems2.domain.Student;
import bitcamp.java89.ems2.util.DataSource;

public class StudentMysqlDao implements StudentDao {
  DataSource ds;
  
  //Singleton 패턴 - start
  private StudentMysqlDao() {
    ds = DataSource.getInstance();
  }
 
  static StudentMysqlDao instance;
 
  public static StudentMysqlDao getInstance() {
    if (instance == null) {
      instance = new StudentMysqlDao();
    }
    return instance;
  }
  // end - Singleton 패턴
 
  public ArrayList<Student> getList() throws Exception {
    ArrayList<Student> list = new ArrayList<>();
    Connection con = ds.getConnection(); // 커넥션풀에서 한 개의 Connection 객체를 임대한다.
    try (
        
      PreparedStatement stmt = con.prepareStatement(
          "select mno, name, tel, email, work, lst_schl, schl_nm, path"
          + " from stud left outer join memb on stud.sno=memb.mno");
      ResultSet rs = stmt.executeQuery(); ){
      
      while (rs.next()) { // 서버에서 레코드 한 개를 가져왔다면,
        Student student = new Student();
        student.setMemberNo(rs.getInt("mno"));
        student.setName(rs.getString("name"));
        student.setTel(rs.getString("tel"));
        student.setEmail(rs.getString("email"));
        student.setWorking(rs.getString("work").equals("Y")? true : false);
        student.setGrade(rs.getString("lst_schl"));
        student.setSchoolName(rs.getString("schl_nm"));
        student.setPhotoPath(rs.getString("path"));
        list.add(student);
//        student.setDetailAddress(rs.getString("det_adr"));
//        student.setPostNo(rs.getString("pst_no"));
//        student.setBasicAddress(rs.getString("bas_adr"));
      } 
    } finally {
      ds.returnConnection(con);
    }
    return list;
  }
  
  
  public Student getOne(String name) throws Exception {
    Connection con = ds.getConnection(); // 커넥션풀에서 한 개의 Connection 객체를 임대한다.
    try (
      PreparedStatement stmt = con.prepareStatement(
          "select name, tel, email, pwd, lst_schl, schl_nm, det_adr, work "
          + " from stud left join memb on stud.sno = memb.mno"
          + " where name=?");) {

      stmt.setString(1, name);
      ResultSet rs = stmt.executeQuery();

      if (rs.next()) { // 서버에서 레코드 한 개를 가져왔다면,
        Student student = new Student();
        student.setName(rs.getString("name"));
        student.setTel(rs.getString("tel"));
        student.setEmail(rs.getString("email"));
        student.setPassword(rs.getString("pwd"));
        student.setGrade(rs.getString("lst_schl"));
        student.setSchoolName(rs.getString("schl_nm"));
        student.setDetailAddress(rs.getString("det_adr"));
        student.setWorking(rs.getBoolean("work"));
        rs.close();
        return student;
        
      } else {
        rs.close();
        return null;
      }
    } finally {
      ds.returnConnection(con);
    }
  }
  
//  public void insert(Student student) throws Exception {
//    Connection con = ds.getConnection(); // 커넥션풀에서 한 개의 Connection 객체를 임대한다.
//    try (
//      PreparedStatement stmt = con.prepareStatement(
//          "insert into ex_students(uid,pwd,name,tel,email,work,byear,schl) "
//          + " values(?,?,?,?,?,?,?,?)"); ) {
//      
////      stmt.setString(1, student.getUserId());
////      stmt.setString(2, student.getPassword());
////      stmt.setString(3, student.getName());
////      stmt.setString(4, student.getTel());
////      stmt.setString(5, student.getEmail());
////      stmt.setString(6, student.isWorking() ? "Y" : "NO");
////      stmt.setInt(7, student.getBirthYear());
////      stmt.setString(8, student.getSchool());
//      
//      stmt.executeUpdate();
//    } finally {
//      ds.returnConnection(con);
//    }
//  }
//  
  public void update(Student student) throws Exception {
    Connection con = ds.getConnection(); // 커넥션풀에서 한 개의 Connection 객체를 임대한다.
    try (
      PreparedStatement stmt = con.prepareStatement(
          "update stud left join memb on stud.sno = memb.mno set "
          + " tel=?,email=?,pwd=?,lst_schl=?,schl_nm=?,det_adr=?,work=?"
          + " where name=?"); ) {
      
      stmt.setString(1, student.getTel());
      stmt.setString(2, student.getEmail());
      stmt.setString(3, student.getPassword());
      stmt.setString(4, student.getGrade());
      stmt.setString(5, student.getSchoolName());
      stmt.setString(6, student.getDetailAddress());
      stmt.setString(7, student.isWorking() ? "Y" : "N"); 
      stmt.setString(8, student.getName());
      
      stmt.executeUpdate();
    } finally {
      ds.returnConnection(con);
    }
  }
  
  public void delete(String name) throws Exception {
    Connection con = ds.getConnection(); // 커넥션풀에서 한 개의 Connection 객체를 임대한다.
    try (
        PreparedStatement stmt = con.prepareStatement(
            "delete from stud where name=?"); 
        PreparedStatement stmt2 = con.prepareStatement(
            "delete from memb where name=?"); ) {
          
      stmt.setString(1, name);
      stmt2.setString(1, name);
      
      stmt.executeUpdate();
      stmt2.executeUpdate();
    } finally {
      ds.returnConnection(con);
    }
  }
  
  public boolean existName(String name) throws Exception {
    Connection con = ds.getConnection(); // 커넥션풀에서 한 개의 Connection 객체를 임대한다.
    try (
      PreparedStatement stmt = con.prepareStatement(
          "select * from stud left join memb on stud.sno = memb.mno where name=?"); ) {
      
      stmt.setString(1, name);
      ResultSet rs = stmt.executeQuery();
      
      if (rs.next()) { // 서버에서 레코드 한 개를 가져왔다면,
        rs.close();
        return true;
      } else {
        rs.close();
        return false;
      }
    } finally {
      ds.returnConnection(con);
    }
  }
}







