package bitcamp.java89.ems2.dao;

import java.util.ArrayList;

import bitcamp.java89.ems2.domain.Student;

public interface StudentDao {

  public ArrayList<Student> getList() throws Exception; 
  public Student getOne(String name) throws Exception;
  public boolean existName(String name) throws Exception;
  public void update(Student student) throws Exception;
  public void delete(String name) throws Exception;
}
