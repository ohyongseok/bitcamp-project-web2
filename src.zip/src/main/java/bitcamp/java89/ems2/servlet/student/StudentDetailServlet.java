package bitcamp.java89.ems2.servlet.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bitcamp.java89.ems2.dao.impl.StudentMysqlDao;
import bitcamp.java89.ems2.domain.Student;

@WebServlet("/student/detail")
public class StudentDetailServlet extends HttpServlet{

  private static final long serialVersionUID = 1L;
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    
    String name = request.getParameter("name");
    response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
    
    out.println("<!DOCTYPE html>");
    out.println("<html>");
    out.println("<head>");
    out.println("<meta charset='UTF-8'>");
//      out.println("<meta name='viewport' content='width=device-with, user-scalable=no, maximum-scale=1'>");
    out.println("<title>학생 관리-상세정보</title>");
    out.println("</head>");
    out.println("<body>");
    out.println("<h1>학생 정보</h1>");
    out.println("<form action='update' method='post'>");
    
    try {
      StudentMysqlDao studentDao = StudentMysqlDao.getInstance();
      Student student = studentDao.getOne(name);
      
      if (student == null) {
        throw new Exception ("해당 이름의 학생이 없습니다");
      }
      
      out.println("<table border ='1'>");
      
      out.printf("<tr><th>이름</th><td>"
          + "<input name='name' type='text' value='%s' readonly></td></tr>\n", student.getName());
      out.printf("<tr><th>전화</th><td>"
          + "<input name='tel' type='text' value='%s'></td></tr>\n", student.getTel());
      out.printf("<tr><th>이메일</th><td>"
          + "<input name='email' type='text' value='%s'></td></tr>\n", student.getEmail());
      out.printf("<tr><th>암호</th><td>"
          + "<input name ='pwd' type='text' value='%s' readonly></td></tr>\n", student.getPassword());
      out.printf("<tr><th>최종학력</th><td>"
          + "<input name='lst_schl' type='text' value='%s'></td></tr>\n", student.getGrade());
      out.printf("<tr><th>학교명</th><td>"
          + "<input name='schl_nm' type='text' value='%s'></td></tr>\n", student.getSchoolName());
      out.printf("<tr><th>상세주소</th><td>"
          + "<input name='det_adr' type='text' value='%s'></td></tr>\n", student.getDetailAddress());
      out.printf("<tr><th>재직여부</th><td><input name='work' type='radio' value='true' >했음<input name='work' type='radio' value='false' >안했음</td></tr>", student.isWorking());
      
      out.println("</table>");
      out.println("<button type='submit'>변경</button>");
      out.printf("<a href='delete?name=%s'>삭제 </a>\n", student.getName());
      
    } catch (Exception e) {
      out.printf("<p>%s</p>\n", e.getMessage());
    }
    out.println("<a href='list'>목록</a>"); 
    out.println("</body>");
    out.println("</html>");
  }
}
