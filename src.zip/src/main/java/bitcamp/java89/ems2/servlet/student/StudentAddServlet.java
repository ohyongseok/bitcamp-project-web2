package bitcamp.java89.ems2.servlet.student;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/student/add")
public class StudentAddServlet extends HttpServlet{

  private static final long serialVersionUID = 1L;

}
